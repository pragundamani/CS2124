/*
  rec08_start.cpp
  Starter Code for required functionality

  Yes, of course, you may add other methods.

  And no, this won't compile. You have to fix the cyclic association
  and implement the methods.
  
 */

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Course {
    friend ostream& operator<<(ostream& os, const Course& rhs);
public:
    // Course methods needed by Registrar
    Course(const string& courseName);
    const string& getName() const;

    // Adding the student to this course's vector of students.
    // Make sure the student is not already in this course. 
    // (Don't fail silently.)
    // This would be called from Registrar::enrollStudentInCourse.
    bool addStudent(Student*);

    // Tell all the students in this course that they are no longer in it.
    // This would be called from Registrar::cancelCourse.
    void removeStudentsFromCourse(); 

private:
    string name;
    vector<Student*> students;
}; // Course class

class Student {
    friend ostream& operator<<(ostream& os, const Student& rhs);
public:
    // Student methods needed by Registrar
    Student(const string& name);
    const string& getName() const;

    // Adding the course to the student's vector of courses.
    // Make sure this student is not already in that course. 
    // (Don't fail silently.)
    // This method would be called from Registrar::enrollStudentInCourse.
    bool addCourse(Course*);

    // Removes the Course from the student's vector of Courses.
    // Needed by Course::removeStudentsFromCourse
    void removedFromCourse(Course*);

private:
    string name;
    vector<Course*> courses;
}; // Student class

class Registrar {
    friend ostream& operator<<(ostream& os, const Registrar& rhs);
public:
    // This default constructor just initializes the two empty vectors.
    // " = default" means we are using the system provided constructor.
    // You don't have to implement anything for this function.
    Registrar() = default;

    // Creates a new course on the heap, if none with courseName
    // exists in Registrar's courses vector. Don't fail silently.
    bool addCourse(const string& courseName);

    // Creates a new student on the heap, if none with studentName
    // exists in Registrar's students vector. Don't fail silently.
    bool addStudent(const string&);

    // If a student with studentName and a course with courseName exist, 
    // then enroll the student in the course. Note, don't fail silently.
    // Do not create any new Student or Course objects.
    bool enrollStudentInCourse(const string& studentName,
                               const string& courseName);

    // Unenroll the students from the course courseName and remove it
    // from the Registrar.
    bool cancelCourse(const string& courseName);

    // Get rid of everything!!!
    void purge();

private:
    size_t findStudent(const string&) const;
    size_t findCourse(const string&) const;

    vector<Course*> courses;
    vector<Student*> students;
}; // Registrar

int main()
{

    Registrar registrar;

    cout << "No courses or students added yet\n";
    cout << registrar << endl;
     
    cout << "AddCourse CS101.001\n";
    registrar.addCourse("CS101.001");
    cout << registrar << endl;

    cout << "AddStudent FritzTheCat\n";
    registrar.addStudent("FritzTheCat");
    cout << registrar << endl;

    cout << "AddCourse CS102.001\n";
    registrar.addCourse("CS102.001");
    cout << registrar << endl;

    cout << "EnrollStudentInCourse FritzTheCat CS102.001\n";
    registrar.enrollStudentInCourse("FritzTheCat", "CS102.001");
    cout << "EnrollStudentInCourse FritzTheCat CS101.001\n";
    registrar.enrollStudentInCourse("FritzTheCat", "CS101.001");
    cout << registrar << endl;

    cout << "EnrollStudentInCourse Bullwinkle CS101.001\n";
    cout << "Should fail, i.e. do nothing, "
         << "since Bullwinkle is not a student.\n";
    registrar.enrollStudentInCourse("Bullwinkle", "CS101.001");
    cout << registrar << endl;

    cout << "CancelCourse CS102.001\n";
    registrar.cancelCourse("CS102.001");
    cout << registrar << endl;
   
    cout << "Purge for start of next semester\n";
    registrar.purge();
    cout << registrar << endl;
} // main
  
